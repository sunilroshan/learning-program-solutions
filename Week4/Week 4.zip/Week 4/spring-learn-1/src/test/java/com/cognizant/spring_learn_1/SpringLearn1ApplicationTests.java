package com.cognizant.spring_learn_1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringLearn1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
