package com.example.jwt_authentication_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtAuthenticationServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
